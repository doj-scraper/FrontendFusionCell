"use client"

import * as React from "react"
import { useSearchParams, useRouter } from "next/navigation"
import {
  Search,
  Package,
  Smartphone,
  Building2,
  Filter,
  ArrowUpDown,
  Loader2,
  Sparkles,
  X,
} from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { PartCard, PartCardSkeleton } from "@/components/part-card"
import { DeviceCard, DeviceCardSkeleton } from "@/components/device-card"
import { BrandCard, BrandCardSkeleton } from "@/components/brand-card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationPrevious,
  PaginationNext,
  PaginationEllipsis,
} from "@/components/ui/pagination"
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"

// Types
interface SearchResultPart {
  id: string
  sku: string
  name: string
  slug: string
  price: number
  comparePrice?: number | null
  image?: string | null
  quality?: string | null
  color?: string | null
  category?: {
    name: string
    slug: string
  } | null
  device?: {
    name: string
    slug: string
    brand: {
      name: string
      slug: string
    }
  } | null
  available: number
}

interface SearchResultDevice {
  id: string
  name: string
  slug: string
  modelNumber?: string | null
  image?: string | null
  releaseYear?: number | null
  brand: {
    name: string
    slug: string
    logo?: string | null
  }
  partCount: number
}

interface SearchResultBrand {
  id: string
  name: string
  slug: string
  logo?: string | null
  description?: string | null
  deviceCount: number
}

interface SearchResults {
  parts: SearchResultPart[]
  devices: SearchResultDevice[]
  brands: SearchResultBrand[]
}

interface SearchResponse {
  success: boolean
  data: SearchResults
  query: string
}

type FilterType = "all" | "parts" | "devices" | "brands"
type SortOption = "relevance" | "price_asc" | "price_desc" | "name_asc" | "name_desc"

const ITEMS_PER_PAGE = 12

// Filter button component
function FilterButton({
  active,
  count,
  onClick,
  children,
}: {
  active: boolean
  count: number
  onClick: () => void
  children: React.ReactNode
}) {
  return (
    <Button
      variant={active ? "default" : "outline"}
      size="sm"
      onClick={onClick}
      className="gap-1.5"
    >
      {children}
      <Badge variant={active ? "secondary" : "outline"} className="ml-1 h-5 px-1.5">
        {count}
      </Badge>
    </Button>
  )
}

// Loading skeleton for the page
function PageLoading() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto mb-8">
        <Skeleton className="h-12 w-full" />
      </div>
      <div className="flex items-center gap-2 mb-6">
        <Skeleton className="h-9 w-20" />
        <Skeleton className="h-9 w-20" />
        <Skeleton className="h-9 w-20" />
        <Skeleton className="h-9 w-20" />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {[...Array(8)].map((_, i) => (
          <PartCardSkeleton key={i} />
        ))}
      </div>
    </div>
  )
}

// No results state
function NoResults({ query }: { query: string }) {
  return (
    <div className="text-center py-16">
      <div className="flex items-center justify-center mb-4">
        <Sparkles className="w-16 h-16 text-muted-foreground/30" />
      </div>
      <h2 className="text-xl font-semibold mb-2">No results found</h2>
      <p className="text-muted-foreground mb-6">
        We couldn't find any results for "{query}"
      </p>
      <div className="flex flex-wrap justify-center gap-3">
        <p className="text-sm text-muted-foreground w-full mb-2">Try searching for:</p>
        {["iPhone screen", "Samsung battery", "iPad", "Motorola"].map((term) => (
          <Button
            key={term}
            variant="outline"
            size="sm"
            onClick={() => (window.location.href = `/search?q=${encodeURIComponent(term)}`)}
          >
            {term}
          </Button>
        ))}
      </div>
    </div>
  )
}

// Result type badge
function ResultTypeBadge({ type }: { type: "part" | "device" | "brand" }) {
  const config = {
    part: { label: "Part", className: "bg-primary/10 text-primary border-primary/20" },
    device: { label: "Device", className: "bg-blue-500/10 text-blue-600 border-blue-500/20 dark:text-blue-400" },
    brand: { label: "Brand", className: "bg-purple-500/10 text-purple-600 border-purple-500/20 dark:text-purple-400" },
  }

  const { label, className } = config[type]

  return (
    <Badge variant="outline" className={cn("text-xs font-medium", className)}>
      {label}
    </Badge>
  )
}

export default function SearchPage() {
  const searchParams = useSearchParams()
  const router = useRouter()

  const query = searchParams.get("q") || ""
  const typeParam = searchParams.get("type") as FilterType || "all"
  const sortParam = searchParams.get("sort") as SortOption || "relevance"
  const pageParam = parseInt(searchParams.get("page") || "1", 10)

  const [results, setResults] = React.useState<SearchResults | null>(null)
  const [loading, setLoading] = React.useState(true)
  const [searchInput, setSearchInput] = React.useState(query)
  const [activeFilter, setActiveFilter] = React.useState<FilterType>(typeParam)
  const [sortBy, setSortBy] = React.useState<SortOption>(sortParam)
  const [currentPage, setCurrentPage] = React.useState(pageParam)

  // Fetch search results
  React.useEffect(() => {
    const fetchResults = async () => {
      if (!query || query.trim().length < 2) {
        setLoading(false)
        return
      }

      setLoading(true)

      try {
        const response = await fetch(
          `/api/search?q=${encodeURIComponent(query)}&type=${activeFilter}&limit=50`
        )
        const data: SearchResponse = await response.json()

        if (data.success) {
          setResults(data.data)
        } else {
          setResults({ parts: [], devices: [], brands: [] })
        }
      } catch (error) {
        console.error("Search error:", error)
        setResults({ parts: [], devices: [], brands: [] })
      } finally {
        setLoading(false)
      }
    }

    fetchResults()
  }, [query, activeFilter])

  // Update URL params
  const updateParams = React.useCallback(
    (updates: Record<string, string | number | null>) => {
      const params = new URLSearchParams(searchParams.toString())

      Object.entries(updates).forEach(([key, value]) => {
        if (value === null || value === "" || value === "all" || value === "relevance" || value === 1) {
          params.delete(key)
        } else {
          params.set(key, String(value))
        }
      })

      router.push(`/search?${params.toString()}`, { scroll: false })
    },
    [router, searchParams]
  )

  // Handle search input submit
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchInput.trim().length >= 2) {
      updateParams({ q: searchInput.trim(), page: null })
    }
  }

  // Handle filter change
  const handleFilterChange = (filter: FilterType) => {
    setActiveFilter(filter)
    setCurrentPage(1)
    updateParams({ type: filter === "all" ? null : filter, page: null })
  }

  // Handle sort change
  const handleSortChange = (sort: SortOption) => {
    setSortBy(sort)
    updateParams({ sort: sort === "relevance" ? null : sort })
  }

  // Handle page change
  const handlePageChange = (page: number) => {
    setCurrentPage(page)
    updateParams({ page: page === 1 ? null : page })
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  // Calculate counts
  const counts = React.useMemo(() => {
    if (!results) return { all: 0, parts: 0, devices: 0, brands: 0 }
    return {
      all: results.parts.length + results.devices.length + results.brands.length,
      parts: results.parts.length,
      devices: results.devices.length,
      brands: results.brands.length,
    }
  }, [results])

  // Sort and paginate results
  const paginatedResults = React.useMemo(() => {
    if (!results) return { parts: [], devices: [], brands: [] }

    const sortArray = <T extends { name: string; price?: number }>(arr: T[]): T[] => {
      const sorted = [...arr]
      switch (sortBy) {
        case "name_asc":
          return sorted.sort((a, b) => a.name.localeCompare(b.name))
        case "name_desc":
          return sorted.sort((a, b) => b.name.localeCompare(a.name))
        case "price_asc":
          return sorted.sort((a, b) => (a.price || 0) - (b.price || 0))
        case "price_desc":
          return sorted.sort((a, b) => (b.price || 0) - (a.price || 0))
        default:
          return sorted
      }
    }

    const start = (currentPage - 1) * ITEMS_PER_PAGE
    const end = start + ITEMS_PER_PAGE

    return {
      parts: sortArray(results.parts).slice(start, end),
      devices: results.devices.slice(start, end),
      brands: results.brands.slice(start, end),
    }
  }, [results, sortBy, currentPage])

  // Calculate total pages
  const totalPages = React.useMemo(() => {
    if (!results) return 1
    const totalItems = counts[activeFilter === "all" ? "all" : activeFilter]
    return Math.ceil(totalItems / ITEMS_PER_PAGE)
  }, [results, counts, activeFilter])

  // Handle part actions
  const handleAddToCart = (part: SearchResultPart) => {
    // TODO: Implement cart functionality
    console.log("Add to cart:", part)
  }

  const handleQuickView = (part: SearchResultPart) => {
    // TODO: Implement quick view modal
    console.log("Quick view:", part)
  }

  // Redirect if no query
  if (!query) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto text-center py-16">
          <Search className="w-16 h-16 mx-auto mb-4 text-muted-foreground/30" />
          <h1 className="text-2xl font-bold mb-2">Search FusionCell</h1>
          <p className="text-muted-foreground mb-6">
            Find parts, devices, and brands from our extensive catalog
          </p>
          <form onSubmit={handleSearch} className="flex gap-2 max-w-md mx-auto">
            <Input
              type="search"
              placeholder="Search parts, devices, SKUs..."
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="flex-1"
              autoFocus
            />
            <Button type="submit" disabled={searchInput.trim().length < 2}>
              Search
            </Button>
          </form>
        </div>
      </div>
    )
  }

  if (loading) {
    return <PageLoading />
  }

  const hasResults = counts.all > 0

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Search Header */}
      <div className="max-w-2xl mx-auto mb-8">
        <form onSubmit={handleSearch} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search parts, devices, SKUs..."
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button type="submit" disabled={searchInput.trim().length < 2}>
            Search
          </Button>
        </form>
      </div>

      {/* Results Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-sm text-muted-foreground">
            {hasResults ? (
              <>
                {counts.all} result{counts.all !== 1 ? "s" : ""} for{" "}
                <span className="font-medium text-foreground">"{query}"</span>
              </>
            ) : (
              <span className="font-medium text-foreground">"{query}"</span>
            )}
          </span>
        </div>

        {hasResults && (
          <div className="flex items-center gap-2">
            <Select value={sortBy} onValueChange={(v) => handleSortChange(v as SortOption)}>
              <SelectTrigger className="w-[160px]">
                <ArrowUpDown className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="relevance">Relevance</SelectItem>
                <SelectItem value="price_asc">Price: Low to High</SelectItem>
                <SelectItem value="price_desc">Price: High to Low</SelectItem>
                <SelectItem value="name_asc">Name: A to Z</SelectItem>
                <SelectItem value="name_desc">Name: Z to A</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}
      </div>

      {/* Filter Tabs */}
      {hasResults && (
        <Tabs
          value={activeFilter}
          onValueChange={(v) => handleFilterChange(v as FilterType)}
          className="mb-6"
        >
          <TabsList>
            <TabsTrigger value="all" className="gap-1.5">
              All
              <Badge variant="secondary" className="h-5 px-1.5">
                {counts.all}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="parts" className="gap-1.5">
              <Package className="w-4 h-4" />
              Parts
              <Badge variant="secondary" className="h-5 px-1.5">
                {counts.parts}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="devices" className="gap-1.5">
              <Smartphone className="w-4 h-4" />
              Devices
              <Badge variant="secondary" className="h-5 px-1.5">
                {counts.devices}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="brands" className="gap-1.5">
              <Building2 className="w-4 h-4" />
              Brands
              <Badge variant="secondary" className="h-5 px-1.5">
                {counts.brands}
              </Badge>
            </TabsTrigger>
          </TabsList>
        </Tabs>
      )}

      {/* Results */}
      {!hasResults ? (
        <NoResults query={query} />
      ) : (
        <>
          {/* All Results */}
          {(activeFilter === "all" || activeFilter === "parts") && paginatedResults.parts.length > 0 && (
            <div className="mb-8">
              {activeFilter === "all" && (
                <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Package className="w-5 h-5 text-primary" />
                  Parts
                </h2>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {paginatedResults.parts.map((part) => (
                  <PartCard
                    key={part.id}
                    part={{
                      ...part,
                      inventory: {
                        quantity: part.available + 1,
                        reserved: 1,
                        available: part.available,
                      },
                    }}
                    onAddToCart={() => handleAddToCart(part)}
                    onQuickView={() => handleQuickView(part)}
                  />
                ))}
              </div>
            </div>
          )}

          {(activeFilter === "all" || activeFilter === "devices") && paginatedResults.devices.length > 0 && (
            <div className="mb-8">
              {activeFilter === "all" && (
                <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-blue-500" />
                  Devices
                </h2>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {paginatedResults.devices.map((device) => (
                  <DeviceCard
                    key={device.id}
                    device={device}
                    onClick={() => router.push(`/devices/${device.slug}`)}
                  />
                ))}
              </div>
            </div>
          )}

          {(activeFilter === "all" || activeFilter === "brands") && paginatedResults.brands.length > 0 && (
            <div className="mb-8">
              {activeFilter === "all" && (
                <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-purple-500" />
                  Brands
                </h2>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {paginatedResults.brands.map((brand) => (
                  <BrandCard
                    key={brand.id}
                    brand={brand}
                    onClick={() => router.push(`/brands/${brand.slug}`)}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center mt-8">
              <Pagination>
                <PaginationContent>
                  <PaginationItem>
                    <PaginationPrevious
                      onClick={() => currentPage > 1 && handlePageChange(currentPage - 1)}
                      className={currentPage <= 1 ? "pointer-events-none opacity-50" : "cursor-pointer"}
                    />
                  </PaginationItem>
                  {[...Array(totalPages)].map((_, i) => {
                    const page = i + 1
                    // Show first page, last page, current page, and pages around current
                    const showPage =
                      page === 1 ||
                      page === totalPages ||
                      Math.abs(page - currentPage) <= 1

                    if (!showPage) {
                      // Show ellipsis for gaps
                      if (page === 2 && currentPage > 3) {
                        return (
                          <PaginationItem key={page}>
                            <PaginationEllipsis />
                          </PaginationItem>
                        )
                      }
                      if (page === totalPages - 1 && currentPage < totalPages - 2) {
                        return (
                          <PaginationItem key={page}>
                            <PaginationEllipsis />
                          </PaginationItem>
                        )
                      }
                      return null
                    }

                    return (
                      <PaginationItem key={page}>
                        <PaginationLink
                          onClick={() => handlePageChange(page)}
                          isActive={currentPage === page}
                          className="cursor-pointer"
                        >
                          {page}
                        </PaginationLink>
                      </PaginationItem>
                    )
                  })}
                  <PaginationItem>
                    <PaginationNext
                      onClick={() => currentPage < totalPages && handlePageChange(currentPage + 1)}
                      className={currentPage >= totalPages ? "pointer-events-none opacity-50" : "cursor-pointer"}
                    />
                  </PaginationItem>
                </PaginationContent>
              </Pagination>
            </div>
          )}
        </>
      )}
    </div>
  )
}
