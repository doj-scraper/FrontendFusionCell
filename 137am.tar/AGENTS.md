# AI Agent Guidelines - FusionCell Project

This document provides guidance for AI agents (Claude, GPT, etc.) working on the FusionCell project.

## Project Context

**FusionCell** is a B2B wholesale e-commerce platform for cell phone repair parts. It's a Next.js 16 application with TypeScript, Prisma, and shadcn/ui.

### Business Domain
- **Industry**: Cell phone repair parts wholesale
- **Target Users**: Repair shops, technicians, bulk buyers
- **Key Entities**: Brands (Apple, Samsung, etc.), Devices, Parts, Inventory
- **Pricing**: Wholesale with MOQ (Minimum Order Quantity) of 5 units

### Current State
- ✅ Core catalog browsing complete
- ✅ Search functionality implemented
- ✅ Device explorer navigation
- 🚧 Cart/Checkout are placeholders
- 🚧 Authentication not implemented
- 🚧 Payment processing not implemented

## Technology Stack Reference

### Required (DO NOT CHANGE)
| Technology | Version | Purpose |
|------------|---------|---------|
| Next.js | 16 | App Router framework |
| TypeScript | 5 | Type safety |
| Prisma | 6.x | ORM |
| PostgreSQL | Neon | Database |
| Tailwind | 4 | Styling |
| shadcn/ui | - | UI components |
| Bun | - | Runtime |

### Available Libraries
- `zustand` - Client state management
- `@tanstack/react-query` - Server state
- `react-hook-form` + `zod` - Form handling
- `next-themes` - Theme switching
- `lucide-react` - Icons
- `framer-motion` - Animations
- `next-auth` - Authentication (v4)

## Code Style Guidelines

### File Naming
```
Components:    kebab-case.tsx     (e.g., part-card.tsx)
Pages:         lowercase          (e.g., src/app/about/page.tsx)
API Routes:    route.ts           (e.g., src/app/api/brands/route.ts)
Hooks:         use-*.ts           (e.g., use-mobile.ts)
Utilities:     lowercase.ts       (e.g., utils.ts)
Types:         PascalCase         (e.g., interface PartData {})
```

### Component Pattern
```tsx
// Use named exports
export function PartCard({ part }: PartCardProps) {
  // Hooks at the top
  const [isHovered, setIsHovered] = useState(false)
  
  // Early returns for loading/error
  if (!part) return <PartCardSkeleton />
  
  // Main render
  return (
    <Card className="...">
      {/* Content */}
    </Card>
  )
}

// Skeleton component nearby
export function PartCardSkeleton() {
  return (
    <Card>
      <Skeleton className="..." />
    </Card>
  )
}
```

### API Route Pattern
```tsx
// src/app/api/example/route.ts
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const param = searchParams.get('param')
    
    const data = await db.model.findMany({
      // Query
    })
    
    return NextResponse.json({
      success: true,
      data
    })
  } catch (error) {
    console.error('API error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch data' },
      { status: 500 }
    )
  }
}
```

### Database Queries
```tsx
// Always use Prisma client from lib/db
import { db } from '@/lib/db'

// Include relations explicitly
const device = await db.device.findUnique({
  where: { slug },
  include: {
    brand: true,
    parts: {
      include: {
        category: true,
        inventory: true
      }
    }
  }
})

// Use transactions for writes
await db.$transaction([
  db.part.create({ ... }),
  db.inventory.create({ ... })
])
```

## UI/UX Standards

### Color Palette (DO NOT USE INDIGO/BLUE)
```css
/* Primary: Teal/Emerald */
--primary: oklch(0.45 0.14 170);

/* For light mode */
background: white/very light gray
text: dark gray (WCAG AA compliant)

/* For dark mode */
background: dark charcoal
text: light gray
primary: brighter teal
```

### Component Usage
```tsx
// ✅ Use existing shadcn/ui components
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'

// ❌ Don't create new UI primitives
// ❌ Don't use indigo/blue colors
// ❌ Don't use inline styles for theming
```

### Responsive Design
```tsx
// Mobile-first approach
<div className="
  grid 
  grid-cols-1        // Mobile: 1 column
  sm:grid-cols-2     // Tablet: 2 columns
  lg:grid-cols-3     // Desktop: 3 columns
  gap-4              // Consistent gap
">
```

### Accessibility Requirements
```tsx
// Always include
- aria-label on buttons/links without text
- aria-hidden on decorative icons
- Proper heading hierarchy
- Focus states for interactive elements
- Alt text for images

<Button aria-label="Add to cart">
  <ShoppingCart aria-hidden="true" />
</Button>
```

## Database Schema Reference

### Core Models
```prisma
Brand → Device → Part → Inventory

// Relationships
Brand 1:N Device
Device 1:N Part
PartCategory 1:N Part
Part 1:1 Inventory
```

### Common Queries

**Get brand with devices:**
```typescript
db.brand.findUnique({
  where: { slug },
  include: { devices: { where: { isActive: true } } }
})
```

**Get device with parts:**
```typescript
db.device.findUnique({
  where: { slug },
  include: {
    brand: true,
    parts: {
      include: { category: true, inventory: true }
    }
  }
})
```

**Get part with inventory:**
```typescript
db.part.findUnique({
  where: { sku },
  include: { device: { include: { brand: true } }, inventory: true }
})
```

## Common Tasks

### Adding a New Page
1. Create directory in `src/app/`
2. Add `page.tsx` (client or server component)
3. Add `loading.tsx` for loading state (optional)
4. Add `error.tsx` for error handling (optional)
5. Link from navigation in `src/components/layout/header.tsx`

### Adding a New API Endpoint
1. Create directory in `src/app/api/`
2. Add `route.ts` with GET/POST/PUT/DELETE handlers
3. Use `db` from `@/lib/db`
4. Return `{ success: boolean, data?: any, error?: string }`

### Adding a New Component
1. Create in `src/components/` or `src/components/ui/`
2. Use named exports
3. Include TypeScript props interface
4. Add skeleton loading version if data-dependent
5. Follow shadcn/ui patterns

### Adding New Parts/Devices
1. Edit `prisma/seed.ts`
2. Run `bun prisma/seed.ts`
3. Or use Prisma Studio: `bunx prisma studio`

## Testing Guidelines

### Manual Testing Checklist
- [ ] Page loads without errors
- [ ] Loading states display correctly
- [ ] Error states handle gracefully
- [ ] Responsive on mobile/tablet/desktop
- [ ] Dark mode works
- [ ] Keyboard navigation works
- [ ] Screen reader friendly

### Lint Command
```bash
bun run lint
```

## Environment Setup

### Required Environment Variables
```env
# Database (PostgreSQL - REQUIRED)
DATABASE_URL="postgresql://username:password@host:5432/database?sslmode=require"

# Authentication (REQUIRED)
NEXTAUTH_SECRET="your-secret-key-here"
NEXTAUTH_URL="http://localhost:3000"
```

> ⚠️ **Important**: The app requires a valid PostgreSQL `DATABASE_URL`. API endpoints will fail at runtime without it.

### Optional Variables
```env
# Email
SMTP_HOST="..."
SMTP_USER="..."
SMTP_PASS="..."
```

## Project-Specific Rules

### DO
- ✅ Use `db` from `@/lib/db` for all database operations
- ✅ Follow existing component patterns
- ✅ Include loading/error states
- ✅ Use TypeScript interfaces for all props
- ✅ Add MOQ of 5 for all parts
- ✅ Use Tomball, TX 77375 as address
- ✅ Use sales@fusioncell.com as contact email
- ✅ Use 1-800-FUSION-1 as phone number
- ✅ Check `/home/z/my-project/worklog.md` before starting
- ✅ Update `/home/z/my-project/worklog.md` after finishing

### DON'T
- ❌ Use indigo or blue as primary colors
- ❌ Create new UI primitives (use shadcn/ui)
- ❌ Use client components unnecessarily
- ❌ Make `fetch` calls in server components
- ❌ Use `prisma` client directly (use `db` from lib)
- ❌ Add phones older than iPhone 11
- ❌ Skip accessibility features
- ❌ Ignore responsive design

## Debugging

### Check Dev Server Logs
```bash
tail -50 /home/z/my-project/dev.log
```

### Prisma Studio
```bash
bunx prisma studio
```

### Database Reset
```bash
bun run db:push
bun run db:seed
```

### Prisma Studio (GUI)
```bash
bun run db:studio
```

## Worklog

**IMPORTANT**: After completing any work, update `/home/z/my-project/worklog.md` with:
- Task ID
- What was done
- Files modified
- Any important decisions

## Quick Reference

### File Locations
| Need | Location |
|------|----------|
| Database schema | `prisma/schema.prisma` |
| Seed data | `prisma/seed.ts` |
| API routes | `src/app/api/*/route.ts` |
| Pages | `src/app/*/page.tsx` |
| Components | `src/components/*.tsx` |
| UI components | `src/components/ui/*.tsx` |
| Layout | `src/components/layout/*.tsx` |
| Utilities | `src/lib/*.ts` |
| Hooks | `src/hooks/*.ts` |

### Key Contacts (Fictional)
- **Company**: FusionCell Wholesale
- **Email**: sales@fusioncell.com
- **Phone**: 1-800-FUSION-1 (1-800-387-4661)
- **Address**: 1400 Market Street, Tomball, TX 77375
- **Hours**: Mon-Fri 8AM-6PM CST, Sat 9AM-2PM CST

---

*Last updated: 2025-01-20*
