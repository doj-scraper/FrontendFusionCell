# FusionCell Next Steps Roadmap

This document outlines the prioritized improvements and features needed to complete the FusionCell wholesale cell phone repair parts platform.

---

## Table of Contents

1. [UI/UX Improvements](#1-uiux-improvements)
2. [Core Features to Implement](#2-core-features-to-implement)
3. [Backend Upgrades](#3-backend-upgrades)
4. [Integration & Automation](#4-integration--automation)
5. [Performance & Optimization](#5-performance--optimization)
6. [Security & Compliance](#6-security--compliance)

---

## 1. UI/UX Improvements

### Priority: High

#### 1.1 Mobile Sticky Cart Button
**Status**: Not Implemented
**Design System Reference**: Section 11 - Mobile UX Guidelines

```
Current: No sticky cart on mobile
Required: Fixed bottom cart button that shows item count and total
```

**Implementation**:
- Create `<MobileCartBar />` component
- Fixed position at bottom of viewport on mobile (< 768px)
- Shows item count, subtotal, and "View Cart" button
- Only visible when cart has items
- Add safe area padding for iOS devices

**Files to Create/Modify**:
- `src/components/mobile-cart-bar.tsx` (new)
- `src/app/layout.tsx` (add component)

---

#### 1.2 Product Detail Page
**Status**: Placeholder
**Design System Reference**: Section 8 - Product Card Design

**Required Elements**:
- Large product image gallery (multiple images)
- Product name, SKU (monospace), price (bold, 18px)
- Quality grade badge
- Stock status with real inventory data
- Quantity selector (respecting MOQ)
- "Add to Cart" button (full width mobile)
- Device compatibility list
- Part specifications/specs table
- Related parts suggestions

**Files to Create/Modify**:
- `src/app/parts/[sku]/page.tsx` (enhance)
- `src/components/part-image-gallery.tsx` (new)
- `src/components/quantity-selector.tsx` (new)
- `src/components/compatibility-list.tsx` (new)

---

#### 1.3 Search Results Page Enhancement
**Status**: Basic Implementation
**Design System Reference**: Section 10 - Search Design

**Improvements Needed**:
- Grouped results by type (Parts, Devices, Brands)
- Filter sidebar on desktop
- Filter drawer on mobile
- Sort options (Price, Name, Relevance)
- Pagination or infinite scroll
- Highlighted search terms in results
- No results state with suggestions

**Files to Modify**:
- `src/app/search/page.tsx`
- `src/components/search-modal.tsx`
- `src/app/api/search/route.ts`

---

#### 1.4 Filter System Implementation
**Status**: Not Implemented
**Design System Reference**: Section 9 - Filter System

**Filter Categories**:
| Filter | Type | Implementation |
|--------|------|----------------|
| Brand | Select | Dropdown with icons |
| Device | Cascading | Brand → Device selector |
| Part Type | Select | Screen, Battery, Charging Port, etc. |
| Quality Grade | Select | OEM, Aftermarket, Premium |
| Price Range | Slider | $0 - $500 range |
| Availability | Toggle | In Stock Only checkbox |

**Desktop**: Left sidebar (280px fixed width)
**Mobile**: Slide-up drawer (bottom sheet)

**Files to Create**:
- `src/components/filter-sidebar.tsx`
- `src/components/filter-drawer.tsx`
- `src/components/price-range-slider.tsx`

---

#### 1.5 Loading States & Skeletons
**Status**: Partial
**Design System Reference**: Performance Guidelines

**Improvements**:
- Add skeleton states to all data-dependent components
- Implement streaming with React Suspense
- Add loading indicators for async operations
- Progressive image loading with blur-up effect

---

### Priority: Medium

#### 1.6 Quick View Modal
**Status**: Not Implemented

**Purpose**: Allow users to preview parts without leaving the catalog page

**Features**:
- Image carousel
- Price, SKU, stock status
- Quality and color options (variants)
- Quantity selector
- Add to cart button
- "View Full Details" link

**Files to Create**:
- `src/components/quick-view-modal.tsx`

---

#### 1.7 Toast Notifications
**Status**: Basic (using sonner)

**Enhancements**:
- Cart add confirmation with undo action
- Stock level warnings
- Price change alerts
- Error messages with retry options

---

#### 1.8 Empty States
**Status**: Basic

**Improvements**:
- Custom illustrations for empty cart, no results, etc.
- Clear call-to-action buttons
- Helpful suggestions

---

#### 1.9 Accessibility Enhancements
**Status**: Good (WCAG AA)

**Additional Needs**:
- Skip-to-main-content link
- Focus management on route changes
- Screen reader announcements for dynamic content
- High contrast mode support
- Reduced motion preferences

---

## 2. Core Features to Implement

### Priority: Critical (MVP)

#### 2.1 Shopping Cart System
**Status**: Placeholder Page Only

**Features Required**:
- Add/remove items with quantity
- Update quantities (min: MOQ)
- Persist cart (localStorage + server sync for logged-in users)
- Calculate totals, estimated shipping
- Apply discount codes
- Save for later functionality
- Recently viewed items

**Database Schema**: Already exists (Order model)

**Files to Create**:
- `src/lib/cart-store.ts` (Zustand store)
- `src/hooks/use-cart.ts`
- `src/app/api/cart/route.ts`
- `src/app/api/cart/[id]/route.ts`
- `src/components/cart-item.tsx`
- `src/components/cart-summary.tsx`

---

#### 2.2 User Authentication
**Status**: Placeholder Page Only
**Technology**: NextAuth.js v4 (installed)

**Features Required**:
- Email/password registration
- Email verification
- Password reset
- Session management
- Role-based access (customer, admin, manager)
- Wholesale account application flow

**Files to Create**:
- `src/app/api/auth/[...nextauth]/route.ts`
- `src/app/auth/login/page.tsx`
- `src/app/auth/register/page.tsx`
- `src/app/auth/forgot-password/page.tsx`
- `src/app/auth/verify-email/page.tsx`
- `src/lib/auth.ts`
- `src/components/auth/login-form.tsx`
- `src/components/auth/register-form.tsx`

---

#### 2.3 Checkout Flow
**Status**: Placeholder Page Only

**Steps**:
1. **Cart Review** - Verify items and quantities
2. **Account/Guest** - Login or continue as guest
3. **Shipping** - Address entry with validation
4. **Payment** - Payment method selection (integration placeholder)
5. **Review** - Order summary and confirmation
6. **Confirmation** - Order number and next steps

**Files to Create**:
- `src/app/checkout/shipping/page.tsx`
- `src/app/checkout/payment/page.tsx`
- `src/app/checkout/review/page.tsx`
- `src/app/checkout/confirmation/page.tsx`
- `src/components/checkout/checkout-progress.tsx`
- `src/components/checkout/shipping-form.tsx`
- `src/components/checkout/order-summary.tsx`

---

#### 2.4 User Account Dashboard
**Status**: Placeholder Page Only

**Features**:
- Order history with status tracking
- Reorder functionality
- Saved addresses
- Account settings
- Wholesale account status
- Invoice downloads
- Support tickets (future)

**Files to Create**:
- `src/app/account/orders/page.tsx`
- `src/app/account/addresses/page.tsx`
- `src/app/account/settings/page.tsx`
- `src/components/account/order-history.tsx`
- `src/components/account/address-book.tsx`

---

### Priority: High

#### 2.5 Inventory Management (Admin)
**Status**: Database schema ready, UI not implemented

**Features**:
- Stock level dashboard
- Low stock alerts
- Inventory adjustment logging
- Bulk inventory updates
- Inventory export (CSV)

**Files to Create**:
- `src/app/admin/inventory/page.tsx`
- `src/app/api/admin/inventory/route.ts`
- `src/components/admin/inventory-table.tsx`
- `src/components/admin/inventory-adjustment-modal.tsx`

---

#### 2.6 Order Management (Admin)
**Status**: Database schema ready, UI not implemented

**Features**:
- Order list with filters (status, date, customer)
- Order detail view
- Status updates (processing → shipped → delivered)
- Tracking number entry
- Order notes
- Invoice generation
- Packing slip printing

**Files to Create**:
- `src/app/admin/orders/page.tsx`
- `src/app/admin/orders/[id]/page.tsx`
- `src/app/api/admin/orders/route.ts`
- `src/components/admin/order-detail.tsx`
- `src/components/admin/order-status-badge.tsx`

---

#### 2.7 Product Management (Admin)
**Status**: Database schema ready, UI not implemented

**Features**:
- Part CRUD operations
- Variant management (quality, color, price)
- Image upload and management
- Bulk import/export
- Featured products selection
- Category management

**Files to Create**:
- `src/app/admin/products/page.tsx`
- `src/app/admin/products/new/page.tsx`
- `src/app/admin/products/[id]/edit/page.tsx`
- `src/app/api/admin/products/route.ts`
- `src/components/admin/product-form.tsx`
- `src/components/admin/variant-manager.tsx`

---

### Priority: Medium

#### 2.8 Quick Reorder System
**Status**: Not Implemented

**Features**:
- "Reorder" button on order history
- One-click add all items to cart
- Recently ordered parts section
- Favorite/pinned parts list

---

#### 2.9 Wishlist/Saved Parts
**Status**: Not Implemented

**Features**:
- Save parts for later
- Organize into lists
- Share lists with team members
- Price drop notifications

---

#### 2.10 Volume Pricing Tiers
**Status**: Database schema partial

**Features**:
- Quantity break pricing (e.g., 5-9, 10-24, 25+)
- Customer-specific pricing
- Tier display on product pages

**Database Changes Needed**:
- Add `VolumePricing` model
- Add `CustomerPricing` model for custom rates

---

## 3. Backend Upgrades

### Priority: Critical

#### 3.1 Database Migration: SQLite → PostgreSQL
**Status**: SQLite (Development), PostgreSQL recommended for production

**Migration Steps**:
1. Install PostgreSQL driver (`pg`)
2. Update Prisma schema for PostgreSQL types
3. Change price fields from `Float` to `Decimal`
4. Run migration with `prisma migrate`
5. Update connection string in production

**Schema Changes**:
```prisma
// Change Float prices to Decimal for money precision
price        Decimal  @db.Decimal(10, 2)
comparePrice Decimal? @db.Decimal(10, 2)
cost         Decimal? @db.Decimal(10, 2)
```

---

#### 3.2 API Route Protection
**Status**: No authentication middleware

**Implementation**:
- Add authentication middleware for protected routes
- Role-based access control for admin routes
- Rate limiting for public endpoints
- Input validation with Zod schemas

**Files to Create**:
- `src/middleware.ts`
- `src/lib/auth-middleware.ts`
- `src/lib/rate-limit.ts`
- `src/lib/validators/` (Zod schemas)

---

#### 3.3 Email Service Integration
**Status**: Not Implemented

**Email Types Needed**:
- Order confirmation
- Shipping notification
- Password reset
- Email verification
- Wholesale account approval
- Low stock alerts (admin)
- Weekly reports (admin)

**Integration Options**:
- Resend (recommended for Next.js)
- SendGrid
- AWS SES

---

### Priority: High

#### 3.4 Real-time Inventory Updates
**Status**: Static inventory queries

**Implementation Options**:
- WebSocket (socket.io) for live updates
- Server-Sent Events (SSE)
- Polling with SWR/React Query

**Use Cases**:
- Stock level changes
- Order status updates
- Admin dashboard metrics

---

#### 3.5 File Storage for Product Images
**Status**: Using placeholder URLs

**Options**:
- AWS S3
- Cloudflare R2 (recommended)
- Vercel Blob Storage

**Features**:
- Image upload with drag-and-drop
- Automatic resizing/optimization
- CDN delivery
- Signed URLs for secure access

---

#### 3.6 Search Enhancement: Full-Text Search
**Status**: Basic LIKE queries

**Options**:
- PostgreSQL Full-Text Search
- Meilisearch (self-hosted)
- Algolia (SaaS)
- Typesense

**Features**:
- Fuzzy matching
- Search suggestions
- Search analytics
- Faceted search

---

### Priority: Medium

#### 3.7 Caching Layer
**Status**: None (direct database queries)

**Implementation**:
- Redis for session storage and caching
- Cache product catalog data
- Cache API responses with stale-while-revalidate
- Cache invalidation on data changes

---

#### 3.8 Background Jobs
**Status**: Not Implemented

**Use Cases**:
- Order processing automation
- Inventory sync with suppliers
- Email queue
- Report generation
- Image processing

**Options**:
- BullMQ with Redis
- Trigger.dev
- Inngest

---

#### 3.9 Analytics & Tracking
**Status**: Not Implemented

**Features**:
- Page view tracking
- Product view tracking
- Search query logging
- Conversion funnel
- Revenue analytics (admin dashboard)

**Options**:
- Google Analytics 4
- Plausible (privacy-focused)
- Mixpanel

---

## 4. Integration & Automation

### Priority: High

#### 4.1 Payment Processing
**Status**: Placeholder

**Options**:
- Stripe (recommended)
- Square
- PayPal Business

**Features**:
- Card payment processing
- ACH transfers (for wholesale)
- Payment method storage
- Refund processing
- Invoice generation

---

#### 4.2 Shipping Integration
**Status**: Not Implemented

**Options**:
- Shippo (multi-carrier)
- EasyPost
- ShipStation

**Features**:
- Rate calculation at checkout
- Label generation
- Tracking updates
- Multi-carrier comparison

---

#### 4.3 Tax Calculation
**Status**: Not Implemented

**Options**:
- TaxJar
- Avalara
- Stripe Tax

**Features**:
- Automatic sales tax calculation
- Tax exemption for resale certificates
- Tax reporting

---

### Priority: Medium

#### 4.4 Inventory Sync with Suppliers
**Status**: Not Implemented

**Features**:
- EDI integration
- FTP/SFTP file exchange
- API integration with major suppliers
- Automated purchase order creation

---

#### 4.5 Accounting Integration
**Status**: Not Implemented

**Options**:
- QuickBooks Online
- Xero
- NetSuite

**Features**:
- Invoice sync
- Expense tracking
- Financial reporting

---

## 5. Performance & Optimization

### Priority: High

#### 5.1 Image Optimization
**Status**: Using standard img tags

**Improvements**:
- Convert to Next.js Image component
- Implement blur placeholders
- WebP/AVIF format conversion
- Lazy loading below fold
- Responsive image sizing

---

#### 5.2 Code Splitting & Bundle Analysis
**Status**: Default Next.js behavior

**Improvements**:
- Analyze bundle with `@next/bundle-analyzer`
- Dynamic imports for heavy components
- Lazy load non-critical libraries
- Reduce initial JavaScript payload

---

#### 5.3 Database Query Optimization
**Status**: Basic queries without optimization

**Improvements**:
- Add database indexes
- Implement query batching
- Use Prisma select for specific fields
- Add query logging in development
- Implement connection pooling

---

## 6. Security & Compliance

### Priority: Critical

#### 6.1 Security Headers
**Status**: Default Next.js

**Implementation**:
- Content Security Policy (CSP)
- X-Frame-Options
- X-Content-Type-Options
- Referrer-Policy
- Permissions-Policy

**File**: `next.config.ts`

---

#### 6.2 Input Validation & Sanitization
**Status**: Partial

**Improvements**:
- Zod schemas for all API inputs
- XSS prevention
- SQL injection prevention (Prisma handles this)
- CSRF protection for forms

---

#### 6.3 Rate Limiting
**Status**: Not Implemented

**Implementation**:
- Limit API requests per IP/user
- Different limits for auth vs. public endpoints
- Redis-backed rate limiting
- Custom error responses

---

### Priority: Medium

#### 6.4 Audit Logging
**Status**: Partial (InventoryMovement exists)

**Expansion**:
- Log all admin actions
- User activity logging
- Security event logging
- Exportable audit trail

---

#### 6.5 Backup & Disaster Recovery
**Status**: Not Implemented

**Requirements**:
- Automated database backups
- Point-in-time recovery
- Backup testing procedures
- Documented recovery process

---

## Implementation Priority Matrix

### Sprint 1 (Week 1-2): MVP Core
| Task | Priority | Effort |
|------|----------|--------|
| Shopping Cart System | Critical | 3 days |
| User Authentication | Critical | 2 days |
| Checkout Flow (Basic) | Critical | 3 days |
| Product Detail Page | Critical | 1 day |
| Mobile Sticky Cart | High | 0.5 day |

### Sprint 2 (Week 3-4): User Features
| Task | Priority | Effort |
|------|----------|--------|
| User Account Dashboard | High | 2 days |
| Order History | High | 1 day |
| Filter System | High | 2 days |
| Search Enhancement | High | 2 days |
| Quick View Modal | Medium | 1 day |

### Sprint 3 (Week 5-6): Admin & Backend
| Task | Priority | Effort |
|------|----------|--------|
| Admin Dashboard | High | 2 days |
| Order Management | High | 2 days |
| Product Management | High | 2 days |
| Inventory Management | High | 2 days |
| API Protection | Critical | 1 day |

### Sprint 4 (Week 7-8): Integrations
| Task | Priority | Effort |
|------|----------|--------|
| Email Service | High | 1 day |
| Payment Processing | High | 2 days |
| Shipping Integration | High | 2 days |
| Tax Calculation | Medium | 1 day |
| Image Storage | High | 1 day |

---

## Technical Debt Items

1. **Seed Script Enhancement**: Add more realistic parts data with actual images
2. **API Response Standardization**: Consistent response format across all endpoints
3. **Error Handling**: Global error boundary and consistent error responses
4. **Testing**: Add unit tests for utilities, integration tests for APIs
5. **Documentation**: API documentation with OpenAPI/Swagger
6. **Environment Configuration**: Better env var management and validation

---

## Resources

- [Design System](./DESIGN-SYSTEM.md)
- [Architecture Documentation](./ARCHITECTURE.md)
- [Agent Guidelines](./AGENTS.md)
- [Prisma Schema](./prisma/schema.prisma)

---

*Last Updated: 2025-01-20*
*Version: 1.0.0*
