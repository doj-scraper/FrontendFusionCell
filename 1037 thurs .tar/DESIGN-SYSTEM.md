# FusionCell Design System

A comprehensive design system for the FusionCell wholesale cell phone repair parts platform.

---

## 1. Design Goals

The interface should communicate:

- **Speed** — Fast ordering, quick scanning
- **Clarity** — Information hierarchy, readable data
- **Reliability** — Professional supply portal
- **Trust** — Established wholesaler feel

### Target Users

| User Type | Behavior | Needs |
|-----------|----------|-------|
| Repair Shop Owners | Bulk ordering, price comparison | Volume pricing, quick reorders |
| Technicians | Quick part lookup | Search by device/SKU, compatibility info |
| Repeat Buyers | Know what they want | Fast checkout, order history |
| Mobile Users | On-the-go ordering | Responsive design, sticky controls |

### Core UX Principles

1. **Quick scanning** — Dense but readable product lists
2. **Fast ordering** — Minimal clicks to purchase
3. **Mobile-first** — Excellent mobile usability
4. **Information density** — Professional, not sparse

---

## 2. Color System

Minimal, neutral base with a single controlled accent.

### Base Palette (Light Mode)

| Role | Color | Hex | Usage |
|------|-------|-----|-------|
| Background | Light Gray | `#F7F8FA` | Main page background |
| Surface | White | `#FFFFFF` | Cards, modals |
| Border | Light Border | `#E5E7EB` | Separators, inputs |
| Text Primary | Dark Gray | `#111827` | Titles, headings |
| Text Secondary | Medium Gray | `#4B5563` | Metadata, descriptions |
| Text Muted | Light Gray | `#9CA3AF` | Labels, placeholders |

### Accent Palette

**Primary Accent (Teal — NOT Indigo/Blue)**

| State | Color | Hex | Usage |
|-------|-------|-----|-------|
| Default | Primary | `#0D9488` | Buttons, links, CTAs |
| Hover | Primary Dark | `#0F766E` | Hover states |
| Active | Primary Darker | `#115E59` | Active/pressed states |
| Light | Primary Light | `#CCFBF1` | Backgrounds, highlights |

```css
/* CSS Variables */
--primary: #0D9488;
--primary-hover: #0F766E;
--primary-active: #115E59;
--primary-light: #CCFBF1;
--primary-foreground: #FFFFFF;
```

### Status Colors

| State | Color | Hex | Usage |
|-------|-------|-----|-------|
| Success/In Stock | Green | `#16A34A` | Stock badges, success states |
| Warning/Low Stock | Amber | `#F59E0B` | Low stock warnings |
| Error/Out of Stock | Red | `#EF4444` | Out of stock, errors |
| Info | Sky | `#0EA5E9` | Informational badges |

**Important**: Status colors represent system state only. Never use decoratively.

### Dark Mode Palette

| Role | Color | Hex |
|------|-------|-----|
| Background | Dark Slate | `#0F172A` |
| Surface | Slate | `#1E293B` |
| Border | Slate Border | `#334155` |
| Text | Light Gray | `#E2E8F0` |
| Primary | Teal Light | `#14B8A6` |

---

## 3. Typography

### Font Stack

**Primary Font**: Inter (fallback: system-ui, sans-serif)

```css
font-family: 'Inter', system-ui, -apple-system, sans-serif;
```

**Monospace Font**: JetBrains Mono (fallback: monospace)

```css
font-family: 'JetBrains Mono', 'Fira Code', monospace;
```

### Type Scale

| Role | Size | Line Height | Weight | Usage |
|------|------|-------------|--------|-------|
| H1 | 32px / 2rem | 1.2 | 700 | Page titles |
| H2 | 24px / 1.5rem | 1.3 | 600 | Section headings |
| H3 | 20px / 1.25rem | 1.4 | 600 | Card titles |
| H4 | 18px / 1.125rem | 1.4 | 600 | Subsection headings |
| Body | 16px / 1rem | 1.5 | 400 | Paragraphs, descriptions |
| Body Small | 14px / 0.875rem | 1.5 | 400 | Secondary text |
| Label | 14px / 0.875rem | 1.4 | 500 | Form labels, tags |
| Caption | 12px / 0.75rem | 1.4 | 400 | Micro text, metadata |

### Font Weights

| Weight | Value | Usage |
|--------|-------|-------|
| Regular | 400 | Body text |
| Medium | 500 | Labels, emphasis |
| Semibold | 600 | Headings, buttons |
| Bold | 700 | Hero text, important numbers |

---

## 4. Spacing System

### Base Unit: 4px

| Token | Size | Usage |
|-------|------|-------|
| space-1 | 4px | Tight spacing |
| space-2 | 8px | Icon margins |
| space-3 | 12px | Component gaps |
| space-4 | 16px | Card padding, section gaps |
| space-5 | 20px | Medium gaps |
| space-6 | 24px | Section margins |
| space-8 | 32px | Large sections |
| space-10 | 40px | Page sections |
| space-12 | 48px | Major sections |
| space-16 | 64px | Hero spacing |

### Container Widths

```css
--container-sm: 640px;
--container-md: 768px;
--container-lg: 1024px;
--container-xl: 1280px;
--container-2xl: 1536px;
```

---

## 5. Layout Grid

### Desktop (≥1024px)

- **Max Width**: 1280px
- **Columns**: 12
- **Gutter**: 24px
- **Margin**: 24px

### Tablet (768px - 1023px)

- **Columns**: 8
- **Gutter**: 20px
- **Margin**: 20px

### Mobile (<768px)

- **Columns**: 4
- **Gutter**: 16px
- **Margin**: 16px

### Grid Classes

```css
.grid-cols-1  /* 1 column */
.grid-cols-2  /* 2 columns */
.grid-cols-3  /* 3 columns */
.grid-cols-4  /* 4 columns */
.grid-cols-6  /* 6 columns */
.grid-cols-12 /* 12 columns */
```

---

## 6. Core Layout Structure

### Header

```
┌────────────────────────────────────────────────────────────┐
│ [Logo]     [═══════ Search ═══════]     [Account] [Cart]  │
│           Apple │ Samsung │ Motorola │ Google             │
└────────────────────────────────────────────────────────────┘
```

**Rules:**
- Search should be **central and large**
- Technicians search by device, part, or SKU
- Search is the **most important control**

### Page Layout (Desktop)

```
┌─────────────────────────────────────────┐
│              HEADER                      │
├────────────┬────────────────────────────┤
│            │                            │
│  FILTERS   │      PRODUCT GRID          │
│            │                            │
│  Brand     │  ┌────┐ ┌────┐ ┌────┐     │
│  Device    │  │    │ │    │ │    │     │
│  Category  │  │    │ │    │ │    │     │
│  Price     │  └────┘ └────┘ └────┘     │
│            │                            │
├────────────┴────────────────────────────┤
│              FOOTER                      │
└─────────────────────────────────────────┘
```

### Page Layout (Mobile)

```
┌─────────────────────┐
│      HEADER         │
├─────────────────────┤
│ [════ Search ════]  │
│ [🔍 Filters]        │
├─────────────────────┤
│                     │
│   PRODUCT LIST      │
│                     │
│   ┌───────────┐     │
│   │  Product  │     │
│   └───────────┘     │
│                     │
├─────────────────────┤
│ [🛒 Cart (3)]       │ ← Sticky
└─────────────────────┘
```

---

## 7. Component Specifications

### Buttons

#### Primary Button

```css
.btn-primary {
  background: var(--primary);
  color: white;
  padding: 10px 20px;
  border-radius: 8px;
  font-weight: 600;
  font-size: 14px;
  transition: background 150ms;
}

.btn-primary:hover {
  background: var(--primary-hover);
}

.btn-primary:active {
  background: var(--primary-active);
}

.btn-primary:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
```

#### Secondary Button

```css
.btn-secondary {
  background: white;
  color: var(--text-primary);
  border: 1px solid var(--border);
  padding: 10px 20px;
  border-radius: 8px;
  font-weight: 500;
}

.btn-secondary:hover {
  background: var(--background);
}
```

#### Button Sizes

| Size | Padding | Font Size | Usage |
|------|---------|-----------|-------|
| Small | 6px 12px | 12px | Inline actions |
| Default | 10px 20px | 14px | Standard buttons |
| Large | 14px 28px | 16px | CTAs, Hero |

**Avoid**: Pill buttons everywhere. Those scream "generic SaaS template."

---

### Cards

#### Product Card

```
┌─────────────────────────┐
│                         │
│      [Product Image]    │
│                         │
├─────────────────────────┤
│ iPhone 13 Pro OLED      │
│ Screen Assembly         │
│                         │
│ Grade: Premium          │
│ Stock: In Stock         │
│                         │
│ $39.50                  │
│                         │
│ [Add to Cart]           │
└─────────────────────────┘
```

#### Card Specifications

```css
.card {
  background: white;
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 16px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

.card:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
}
```

**Rules:**
- Price should be **bold**
- Stock color coded
- Product title max 2 lines (truncate with ellipsis)
- Buttons **full width on mobile**

---

### Badges

```css
.badge {
  display: inline-flex;
  align-items: center;
  padding: 4px 8px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
}

.badge-success { background: #DCFCE7; color: #16A34A; }
.badge-warning { background: #FEF3C7; color: #D97706; }
.badge-error { background: #FEE2E2; color: #DC2626; }
.badge-info { background: #E0F2FE; color: #0284C7; }
```

---

### Input Fields

```css
.input {
  height: 40px;
  padding: 0 12px;
  border: 1px solid var(--border);
  border-radius: 8px;
  font-size: 14px;
  background: white;
}

.input:focus {
  outline: none;
  border-color: var(--primary);
  box-shadow: 0 0 0 3px var(--primary-light);
}

.input:disabled {
  background: var(--background);
  cursor: not-allowed;
}
```

---

### Tables

#### Specifications

```css
.table-header {
  background: var(--background);
  font-weight: 600;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

.table-row {
  height: 48px;
  border-bottom: 1px solid var(--border);
}

.table-row:hover {
  background: #F9FAFB;
}

.table-cell-number {
  font-variant-numeric: tabular-nums;
}
```

**Use tabular numerals for price/quantity alignment.**

---

## 8. Product Card Design

### Required Information

| Element | Priority | Style |
|---------|----------|-------|
| Product Image | High | Centered, 200x200px |
| Product Name | High | Bold, 14px, max 2 lines |
| SKU | Medium | Monospace, 12px, muted |
| Price | High | Bold, 18px, primary color |
| Compare Price | Medium | Strikethrough, muted |
| Stock Status | High | Badge, color-coded |
| Quality Grade | Medium | Badge |
| MOQ | Medium | Small text |
| Add to Cart | High | Full-width button |

### Mobile Product Card

```
┌─────────────────────────┐
│ [Img]  Product Name     │
│        SKU: FC-XXX      │
│        Grade │ Stock    │
│        $XX.XX  MOQ: 5   │
│        [Add to Cart]    │
└─────────────────────────┘
```

---

## 9. Filter System

### Filter Categories

| Filter | Type | Options |
|--------|------|---------|
| Brand | Select | Apple, Samsung, Motorola, Google |
| Device | Cascading | iPhone 13 → iPhone 13 Pro |
| Part Type | Select | Screen, Battery, Charging Port... |
| Quality Grade | Select | OEM, Aftermarket, Premium |
| Price Range | Slider | $0 - $500 |
| Availability | Toggle | In Stock Only |

### Desktop Implementation

- Left sidebar (fixed width: 280px)
- Collapsible sections
- Clear all button at top

### Mobile Implementation

- Slide-up drawer (bottom sheet)
- Filter button in header (always visible)
- Apply/Reset buttons fixed at bottom

---

## 10. Search Design

### Search Bar

```css
.search-bar {
  height: 48px;
  padding: 0 16px;
  border-radius: 12px;
  background: white;
  border: 1px solid var(--border);
  display: flex;
  align-items: center;
  gap: 12px;
}

.search-bar:focus-within {
  border-color: var(--primary);
  box-shadow: 0 0 0 3px var(--primary-light);
}
```

### Search Results

- Grouped by type (Parts, Devices, Brands)
- Maximum 10 results per group
- Keyboard navigation (↑↓ Enter)
- Highlighted match text

### Search Shortcuts

- `CMD+K` / `Ctrl+K`: Open search
- `ESC`: Close search
- `Enter`: Select first result

---

## 11. Mobile UX Guidelines

### Critical Rules

1. **Search always visible** — Sticky in header
2. **Sticky cart button** — Fixed at bottom
3. **Large tap targets** — Minimum 44x44px
4. **Simplified filters** — Drawer, not sidebar

### Touch Targets

| Element | Minimum Size |
|---------|--------------|
| Buttons | 44x44px |
| Links | 44x44px |
| Checkboxes | 44x44px |
| Radio buttons | 44x44px |

### Mobile Navigation

```
┌─────────────────────┐
│ ☰  FusionCell   🛒 │  ← Header
├─────────────────────┤
│ [═════ Search ════] │  ← Search
├─────────────────────┤
│ Content             │
│                     │
│                     │
├─────────────────────┤
│ [View Cart (3)]     │  ← Sticky
└─────────────────────┘
```

---

## 12. Interaction States

### Button States

| State | Visual Change |
|-------|---------------|
| Default | Primary color |
| Hover | Darken 10% |
| Active/Pressed | Darken 20%, scale 0.98 |
| Focus | Focus ring |
| Disabled | Opacity 50%, no pointer |
| Loading | Spinner, disabled |

### Card States

| State | Visual Change |
|-------|---------------|
| Default | Light shadow |
| Hover | Increase shadow, lift slightly |
| Selected | Primary border |

### Form States

| State | Visual Change |
|-------|---------------|
| Default | Gray border |
| Focus | Primary border, focus ring |
| Error | Red border, error message |
| Success | Green border (optional) |

---

## 13. Accessibility Requirements

### Color Contrast

- **Text**: Minimum 4.5:1 contrast ratio (WCAG AA)
- **Large Text**: Minimum 3:1 contrast ratio
- **UI Components**: Minimum 3:1 contrast ratio

### Focus Indicators

```css
:focus-visible {
  outline: 2px solid var(--primary);
  outline-offset: 2px;
}
```

### Screen Reader Support

- All images require alt text
- Icons should have `aria-hidden="true"` when decorative
- Buttons must have accessible labels
- Form inputs must have associated labels

### Keyboard Navigation

| Key | Action |
|-----|--------|
| Tab | Move focus forward |
| Shift+Tab | Move focus backward |
| Enter | Activate buttons/links |
| Space | Toggle checkboxes |
| Escape | Close modals/dropdowns |
| Arrow keys | Navigate lists/menus |

---

## 14. Icons

### Icon Library

**Use**: Lucide Icons (already installed)

### Icon Sizes

| Size | Usage |
|------|-------|
| 16px | Inline with small text |
| 20px | Standard UI icons |
| 24px | Navigation icons |
| 32px | Large feature icons |

### Icon Style

```css
.icon {
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-linejoin: round;
}
```

**Consistency over creativity.**

---

## 15. Performance Guidelines

### Target Metrics

| Metric | Target |
|--------|--------|
| First Contentful Paint | < 1.5s |
| Largest Contentful Paint | < 2.5s |
| Time to Interactive | < 3s |
| Cumulative Layout Shift | < 0.1 |

### Optimization Rules

**DO:**
- Lazy load images below fold
- Use Next.js Image component
- Minimize JavaScript bundles
- Use CSS for animations

**DON'T:**
- Giant hero animations
- Heavy gradients
- Unoptimized images
- Too many webfonts

**Remember**: Repair shops will abandon slow sites.

---

## 16. Conversion Elements

### Key Components

| Component | Purpose |
|-----------|---------|
| Quick Reorder Button | Repeat purchases |
| Quantity Stepper | Easy quantity selection |
| Bundle Suggestions | Increase order value |
| Shipping Estimator | Reduce checkout friction |
| Warranty Badge | Build trust |
| Stock Counter | Create urgency |

### Trust Signals

- "30-Day Returns"
- "Quality Guaranteed"
- "Same-Day Shipping"
- "Expert Support"
- Customer testimonials
- Business credentials

---

## 17. Animation Guidelines

### Timing

```css
--duration-fast: 150ms;
--duration-normal: 250ms;
--duration-slow: 350ms;
```

### Easing

```css
--ease-in-out: cubic-bezier(0.4, 0, 0.2, 1);
--ease-out: cubic-bezier(0, 0, 0.2, 1);
--ease-in: cubic-bezier(0.4, 0, 1, 1);
```

### Use Cases

| Animation | Duration | Usage |
|-----------|----------|-------|
| Hover | 150ms | Button hover, card hover |
| Modal | 250ms | Dialog open/close |
| Page Transition | 350ms | Route changes |

**Keep animations subtle. This is a parts catalog, not a meditation app.**

---

## 18. Design Philosophy

### What the UI Should Feel Like

> A well-organized supply warehouse

**Not:**
- A startup landing page
- A crypto dashboard
- A design experiment
- A meditation app

### Core Principles

1. **Clarity wins** — Information over aesthetics
2. **Speed matters** — Fast loading, quick actions
3. **Density is good** — Show more, scroll less
4. **Consistency is key** — Same patterns everywhere
5. **Accessibility is mandatory** — WCAG AA minimum

---

## 19. Design Tokens Reference

### Complete Token List

```css
:root {
  /* Colors */
  --color-background: #F7F8FA;
  --color-surface: #FFFFFF;
  --color-border: #E5E7EB;
  --color-text-primary: #111827;
  --color-text-secondary: #4B5563;
  --color-text-muted: #9CA3AF;
  
  --color-primary: #0D9488;
  --color-primary-hover: #0F766E;
  --color-primary-active: #115E59;
  --color-primary-light: #CCFBF1;
  
  --color-success: #16A34A;
  --color-warning: #F59E0B;
  --color-error: #EF4444;
  --color-info: #0EA5E9;
  
  /* Typography */
  --font-family-sans: 'Inter', system-ui, sans-serif;
  --font-family-mono: 'JetBrains Mono', monospace;
  
  --font-size-xs: 12px;
  --font-size-sm: 14px;
  --font-size-base: 16px;
  --font-size-lg: 18px;
  --font-size-xl: 20px;
  --font-size-2xl: 24px;
  --font-size-3xl: 32px;
  
  /* Spacing */
  --space-1: 4px;
  --space-2: 8px;
  --space-3: 12px;
  --space-4: 16px;
  --space-5: 20px;
  --space-6: 24px;
  --space-8: 32px;
  --space-10: 40px;
  --space-12: 48px;
  --space-16: 64px;
  
  /* Radii */
  --radius-sm: 4px;
  --radius-md: 6px;
  --radius-lg: 8px;
  --radius-xl: 10px;
  --radius-2xl: 12px;
  --radius-full: 9999px;
  
  /* Shadows */
  --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
  --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.05);
  --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.08);
  
  /* Transitions */
  --duration-fast: 150ms;
  --duration-normal: 250ms;
  --ease-in-out: cubic-bezier(0.4, 0, 0.2, 1);
}
```

---

*Last Updated: 2025-01-20*
*Version: 1.0.0*
