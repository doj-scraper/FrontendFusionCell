# PostgreSQL Database Configuration

FusionCell uses PostgreSQL as its primary database. This guide explains the database setup and configuration.

---

## Current Database Status

| Component | Status |
|-----------|--------|
| Database Provider | PostgreSQL (Neon) |
| Prisma Version | 6.x |
| Driver | `pg` |
| Schema | Production-ready |
| Data Seeding | ✅ Complete |

> **Note**: The app is configured for PostgreSQL only. SQLite is no longer supported.

---

## Quick Start: Setting Up Your Database

### Option 1: Neon (Recommended - Free)

1. **Create Neon Account** (2 minutes)
   - Go to [neon.tech](https://neon.tech)
   - Sign up with GitHub or email
   - Create a new project named "fusioncell"

2. **Copy the Connection String**
   ```
   postgresql://username:password@ep-xxx.us-east-2.aws.neon.tech/fusioncell?sslmode=require
   ```

3. **Update your `.env` file**
   ```env
   DATABASE_URL="postgresql://username:password@ep-xxx.us-east-2.aws.neon.tech/fusioncell?sslmode=require"
   ```

### Option 2: Supabase (Free)

1. Go to [supabase.com](https://supabase.com)
2. Create new project
3. Go to Project Settings → Database
4. Copy the connection string:
   ```
   postgresql://postgres:[PASSWORD]@db.[PROJECT-REF].supabase.co:5432/postgres
   ```

### Option 3: Railway (Free $5/month Credit)

1. Go to [railway.app](https://railway.app)
2. Create new project → Add PostgreSQL
3. Copy connection string from variables

---

## Environment Configuration

Create a `.env` file in the project root:

```env
# REQUIRED - PostgreSQL connection string
DATABASE_URL="postgresql://username:password@host:5432/database?sslmode=require"

# REQUIRED - NextAuth configuration
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="your-secret-key-here"

# OPTIONAL
NODE_ENV="development"
```

> ⚠️ **Important**: The app will not run without a valid `DATABASE_URL`. API endpoints will fail at runtime.

---

## Database Setup Commands

```bash
# Generate Prisma client (required after git pull)
bun run db:generate

# Push schema changes to database
bun run db:push

# Seed database with sample data
bun run db:seed

# Open Prisma Studio (GUI for database)
bun run db:studio

# Run migrations (production)
bun run db:migrate
```

---

## Database Schema Overview

### Core Models

```
Brand (Apple, Samsung, Motorola, Google)
  └── Device (iPhone 13 Pro, Galaxy S24, etc.)
        └── Part (Screen, Battery, Charging Port, etc.)
              └── Inventory (quantity, location, reorder point)
```

### Tables

| Table | Description | Sample Count |
|-------|-------------|--------------|
| `Brand` | Device manufacturers | 4 |
| `Device` | Phone models | 76 |
| `Part` | Repair parts | 286 |
| `PartCategory` | Part categories | 6 |
| `Inventory` | Stock levels | 286 |
| `Supplier` | Parts suppliers | 4 |
| `User` | User accounts | - |
| `Order` | Customer orders | - |
| `OrderItem` | Order line items | - |
| `SiteSetting` | App configuration | 7 |

---

## Troubleshooting

### Connection Refused
```
Error: Connection refused
```
**Solution**: Check if PostgreSQL is running, verify host/port in connection string.

### SSL Required
```
Error: SSL connection required
```
**Solution**: Add `?sslmode=require` to your connection string.

### Authentication Failed
```
Error: FATAL: password authentication failed
```
**Solution**: Verify username/password in connection string.

### Prisma Client Errors
```
Error: Prisma Client could not be generated
```
**Solution**: 
```bash
bun run db:generate
```

### Schema Out of Sync
```
Error: The table "public.Brand" does not exist
```
**Solution**: 
```bash
bun run db:push
bun run db:seed
```

---

## Production Checklist

Before deploying to production:

- [ ] Database connection string is set (not using development database)
- [ ] `NEXTAUTH_SECRET` is a secure random string
- [ ] `NEXTAUTH_URL` matches your production URL
- [ ] Database has been seeded with initial data
- [ ] Run `bun run db:generate` to ensure Prisma client is up to date
- [ ] Rotate database credentials after initial setup

---

## Local PostgreSQL (Optional)

If you prefer running PostgreSQL locally:

### macOS (Homebrew)
```bash
brew install postgresql@15
brew services start postgresql@15
createdb fusioncell
```

### Ubuntu/Debian
```bash
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo -u postgres createdb fusioncell
```

### Connection String
```
DATABASE_URL="postgresql://postgres:password@localhost:5432/fusioncell"
```

---

*Last Updated: 2025-01-20*
