# FusionCell Architecture Documentation

## System Overview

FusionCell is a server-side rendered Next.js application with a PostgreSQL database (Neon), designed as a wholesale B2B e-commerce platform for cell phone repair parts.

```
┌─────────────────────────────────────────────────────────────────┐
│                         Client (Browser)                         │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐  │
│  │  React UI   │  │  Zustand    │  │  TanStack Query Cache   │  │
│  │ Components  │  │  (Client)   │  │  (Server State)         │  │
│  └──────┬──────┘  └──────┬──────┘  └───────────┬─────────────┘  │
└─────────┼────────────────┼─────────────────────┼────────────────┘
          │                │                     │
          ▼                ▼                     ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Next.js 16 App Router                       │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                    Server Components                     │    │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌─────────┐  │    │
│  │  │  Pages   │  │  Layouts │  │  Loading │  │  Error  │  │    │
│  │  │  (RSC)   │  │          │  │  States  │  │  Pages  │  │    │
│  │  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬────┘  │    │
│  └───────┼─────────────┼─────────────┼─────────────┼────────┘    │
│          │             │             │             │              │
│  ┌───────┴─────────────┴─────────────┴─────────────┴────────┐    │
│  │                    API Route Handlers                     │    │
│  │  /api/brands  /api/devices  /api/parts  /api/search      │    │
│  └────────────────────────────┬─────────────────────────────┘    │
└───────────────────────────────┼──────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Data Layer (Prisma)                         │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │                    Prisma Client                          │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐       │   │
│  │  │   Query     │  │  Migration  │  │   Schema    │       │   │
│  │  │   Builder   │  │   System    │  │  Validation │       │   │
│  │  └──────┬──────┘  └─────────────┘  └─────────────┘       │   │
│  └─────────┼────────────────────────────────────────────────┘   │
└────────────┼────────────────────────────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────────────────────────────┐
│                   PostgreSQL Database (Neon)                     │
│  ┌────────────┐ ┌────────────┐ ┌────────────┐ ┌─────────────┐  │
│  │   Brand    │ │   Device   │ │    Part    │ │  Inventory  │  │
│  └────────────┘ └────────────┘ └────────────┘ └─────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

## Directory Structure

```
/home/z/my-project/
├── prisma/
│   ├── schema.prisma      # Database schema definition (PostgreSQL)
│   └── seed.ts            # Database seeding script
├── src/
│   ├── app/               # Next.js App Router
│   │   ├── api/           # REST API routes
│   │   │   ├── brands/    # Brand endpoints
│   │   │   ├── devices/   # Device endpoints
│   │   │   ├── parts/     # Parts endpoints
│   │   │   ├── search/    # Search endpoint
│   │   │   └── contact/   # Contact form endpoint
│   │   ├── about/         # About page
│   │   ├── account/       # Account pages (placeholder)
│   │   ├── brand/[slug]/  # Dynamic brand pages
│   │   ├── cart/          # Cart page (placeholder)
│   │   ├── checkout/      # Checkout (placeholder)
│   │   ├── contact/       # Contact page
│   │   ├── device/[slug]/ # Dynamic device pages
│   │   ├── return-policy/ # Policy pages
│   │   ├── search/        # Search results
│   │   ├── terms/         # Terms page
│   │   ├── globals.css    # Global styles
│   │   ├── layout.tsx     # Root layout
│   │   └── page.tsx       # Homepage
│   ├── components/
│   │   ├── layout/        # Layout components
│   │   │   ├── header.tsx
│   │   │   ├── footer.tsx
│   │   │   └── main-layout.tsx
│   │   ├── ui/            # shadcn/ui components
│   │   ├── brand-card.tsx
│   │   ├── device-card.tsx
│   │   ├── device-explorer.tsx
│   │   ├── part-card.tsx
│   │   ├── search-modal.tsx
│   │   └── theme-provider.tsx
│   ├── hooks/             # Custom React hooks
│   └── lib/               # Utilities and libraries
│       ├── db.ts          # Prisma client
│       └── utils.ts       # Helper functions
├── docs/                  # Documentation
│   └── DATABASE-MIGRATION.md
├── public/                # Static assets
├── tailwind.config.ts     # Tailwind configuration
├── next.config.ts         # Next.js configuration
├── worklog.md             # Development work log
└── README.md              # Project documentation
```

## Database Schema

### Entity Relationship Diagram

```
┌─────────────────┐       ┌─────────────────┐
│     Brand       │       │ PartCategory    │
├─────────────────┤       ├─────────────────┤
│ id (PK)         │       │ id (PK)         │
│ name            │       │ name            │
│ slug (unique)   │       │ slug (unique)   │
│ logo            │       │ description     │
│ description     │       │ icon            │
│ isActive        │       │ sortOrder       │
│ sortOrder       │       └────────┬────────┘
└────────┬────────┘                │
         │                         │
         │ 1:N                     │ 1:N
         │                         │
         ▼                         │
┌─────────────────┐                │
│     Device      │                │
├─────────────────┤                │
│ id (PK)         │                │
│ brandId (FK)    │────────────────┘
│ name            │
│ slug (unique)   │
│ modelNumber     │
│ image           │
│ releaseYear     │
│ isActive        │
│ sortOrder       │
└────────┬────────┘
         │
         │ 1:N
         │
         ▼
┌─────────────────┐       ┌─────────────────┐
│      Part       │       │    Inventory    │
├─────────────────┤       ├─────────────────┤
│ id (PK)         │       │ id (PK)         │
│ deviceId (FK)   │       │ partId (FK, UK) │
│ categoryId (FK) │───────│ quantity        │
│ sku (unique)    │       │ reserved        │
│ name            │       │ reorderPoint    │
│ slug (unique)   │       │ location        │
│ description     │       │ lastRestock     │
│ price           │       └─────────────────┘
│ comparePrice    │
│ cost            │
│ quality         │
│ color           │
│ minOrderQty     │
│ isActive        │
│ isFeatured      │
└─────────────────┘
```

### Prisma Schema Details

```prisma
model Brand {
  id          String   @id @default(cuid())
  name        String   @unique
  slug        String   @unique
  logo        String?
  description String?
  isActive    Boolean  @default(true)
  sortOrder   Int      @default(0)
  devices     Device[]
}

model Device {
  id          String   @id @default(cuid())
  brandId     String
  name        String
  slug        String   @unique
  modelNumber String?
  image       String?
  releaseYear Int?
  isActive    Boolean  @default(true)
  sortOrder   Int      @default(0)
  brand       Brand    @relation(fields: [brandId], references: [id])
  parts       Part[]
}

model Part {
  id           String   @id @default(cuid())
  deviceId     String
  categoryId   String
  sku          String   @unique
  name         String
  slug         String   @unique
  description  String?
  price        Float
  comparePrice Float?
  cost         Float?
  quality      String?  // OEM, Aftermarket, Premium
  color        String?
  minOrderQty  Int      @default(5)
  isActive     Boolean  @default(true)
  isFeatured   Boolean  @default(false)
  device       Device       @relation(fields: [deviceId], references: [id])
  category     PartCategory @relation(fields: [categoryId], references: [id])
  inventory    Inventory?
}

model PartCategory {
  id          String   @id @default(cuid())
  name        String   @unique
  slug        String   @unique
  description String?
  icon        String?
  sortOrder   Int      @default(0)
  parts       Part[]
}

model Inventory {
  id           String   @id @default(cuid())
  partId       String   @unique
  quantity     Int      @default(0)
  reserved     Int      @default(0)
  reorderPoint Int      @default(10)
  location     String?  // Warehouse bin location
  part         Part     @relation(fields: [partId], references: [id])
}
```

## API Architecture

### Response Format

All API endpoints follow a consistent response format:

```typescript
// Success Response
{
  success: true,
  data: T,
  meta?: {
    pagination?: {
      page: number,
      limit: number,
      total: number,
      totalPages: number
    },
    filters?: object
  }
}

// Error Response
{
  success: false,
  error: string,
  code?: string
}
```

### API Route Implementations

#### GET /api/brands
```typescript
// Returns all active brands with device counts
// Includes aggregation for device count per brand
const brands = await prisma.brand.findMany({
  where: { isActive: true },
  orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
  include: {
    _count: { select: { devices: { where: { isActive: true } } } }
  }
});
```

#### GET /api/brands/[slug]
```typescript
// Returns brand with all devices
const brand = await prisma.brand.findUnique({
  where: { slug },
  include: {
    devices: {
      where: { isActive: true },
      orderBy: [{ releaseYear: 'desc' }, { sortOrder: 'asc' }]
    }
  }
});
```

#### GET /api/devices/[slug]
```typescript
// Returns device with parts and inventory
const device = await prisma.device.findUnique({
  where: { slug },
  include: {
    brand: true,
    parts: {
      where: { isActive: true },
      include: {
        category: true,
        inventory: true
      }
    }
  }
});
```

#### GET /api/parts
```typescript
// Paginated parts list with filtering
// Query params: page, limit, deviceId, categoryId, brandId, quality, inStock, featured
const parts = await prisma.part.findMany({
  where: filters,
  skip: (page - 1) * limit,
  take: limit,
  include: {
    device: { include: { brand: true } },
    category: true,
    inventory: true
  }
});
```

#### GET /api/search
```typescript
// Full-text search across parts, devices, and brands
// Minimum query length: 2 characters
// Returns grouped results by type
```

## Frontend Architecture

### Component Hierarchy

```
RootLayout (src/app/layout.tsx)
└── ThemeProvider
    └── MainLayout
        ├── Header
        │   ├── Logo
        │   ├── SearchBar → opens SearchModal
        │   ├── Navigation (About, Contact, Return Policy, Terms)
        │   ├── ThemeToggle
        │   ├── AccountButton
        │   ├── CartButton
        │   └── MobileMenu (Sheet)
        ├── <main> (page content)
        │   └── [Page-specific components]
        └── Footer
            ├── Company Info
            ├── Quick Links
            ├── Device Categories
            ├── Contact Info
            └── Social Links
```

### State Management

1. **Server State** (TanStack Query pattern via fetch)
   - Parts, devices, brands data
   - Search results
   - Inventory status

2. **Client State** (Zustand - available but minimal usage)
   - Theme preference (handled by next-themes)
   - Search modal open/close

3. **Form State** (React Hook Form)
   - Contact form
   - Account forms

### Data Flow

```
User Action → Component → fetch(API) → JSON Response → State Update → Re-render

Example: Browsing to iPhone 13 Pro parts
1. User clicks "Apple" → navigates to /brand/apple
2. BrandPage fetches /api/brands/apple
3. Response includes all Apple devices
4. User clicks "iPhone 13 Pro" → navigates to /device/iphone-13-pro
5. DevicePage fetches /api/devices/iphone-13-pro
6. Response includes device + all parts with inventory
7. User can filter/sort parts client-side
```

## Styling Architecture

### CSS Variables (globals.css)

```css
:root {
  /* Light Theme - WCAG AA Compliant */
  --background: oklch(0.99 0 0);           /* Near white */
  --foreground: oklch(0.20 0.02 260);      /* Dark gray */
  --primary: oklch(0.45 0.14 170);         /* Teal - 4.5:1 contrast */
  --primary-foreground: oklch(0.99 0 0);
  --muted: oklch(0.97 0.005 260);
  --border: oklch(0.92 0.01 260);
  /* ... */
}

.dark {
  /* Dark Theme */
  --background: oklch(0.15 0.02 260);
  --foreground: oklch(0.95 0.01 260);
  --primary: oklch(0.65 0.15 170);         /* Brighter teal for dark mode */
  /* ... */
}
```

### Component Styling Pattern

```tsx
// Using Tailwind + shadcn/ui
<Card className="hover:shadow-lg transition-shadow">
  <CardHeader>
    <CardTitle className="text-lg">...</CardTitle>
  </CardHeader>
  <CardContent className="p-4">
    {/* Content */}
  </CardContent>
</Card>
```

## Search Implementation

### Command Palette (CMD+K)

```tsx
// src/components/search-modal.tsx
// Uses shadcn/ui Command component
// Debounced search (300ms)
// Grouped results: Parts, Devices, Brands
// Keyboard navigation (arrows, enter, escape)
```

### Search Results Page

```tsx
// src/app/search/page.tsx
// URL-based state: /search?q=term&type=all&sort=relevance&page=1
// Server-side pagination (12 items per page)
// Filter tabs with counts
```

## Accessibility Implementation

1. **Semantic HTML**
   - `<main>`, `<header>`, `<footer>`, `<nav>`, `<article>`
   - Proper heading hierarchy (h1 → h6)

2. **ARIA Labels**
   - All buttons have aria-label
   - Icons have aria-hidden="true"
   - Form inputs have associated labels

3. **Keyboard Navigation**
   - All interactive elements focusable
   - Tab order logical
   - Skip links available
   - CMD+K opens search

4. **Color Contrast**
   - WCAG AA compliant (4.5:1 minimum)
   - Primary teal tested against white/black

## Performance Considerations

1. **Server Components**: Most pages are server-rendered
2. **Static Generation**: Available for catalog pages
3. **Image Optimization**: Next.js Image component ready
4. **Database Indexes**: 
   - slug fields (unique)
   - sku (unique)
   - deviceId, categoryId, brandId

## Future Implementation Notes

### Authentication (NextAuth.js v4)
```typescript
// Available in package.json
// Schema includes User model
// Needs: credentials provider, session handling
```

### Shopping Cart
```typescript
// Placeholder at /cart
// Needs: 
// - Cart store (Zustand)
// - Cart API endpoints
// - Local storage persistence
// - Server sync for logged-in users
```

### Checkout
```typescript
// Placeholder at /checkout
// Order schema exists
// Needs:
// - Payment integration (Stripe)
// - Shipping calculation
// - Order confirmation flow
// - Email notifications
```

## Deployment

### Build Command
```bash
bun run build
```

### Environment Variables
```env
# REQUIRED - PostgreSQL connection string
DATABASE_URL="postgresql://username:password@host:5432/database?sslmode=require"

# REQUIRED - NextAuth configuration
NEXTAUTH_SECRET="your-secret-key"
NEXTAUTH_URL="http://localhost:3000"
```

### Production Considerations
- PostgreSQL (Neon) for production scalability
- Add Redis for caching
- Add CDN for static assets
- Enable connection pooling for database
